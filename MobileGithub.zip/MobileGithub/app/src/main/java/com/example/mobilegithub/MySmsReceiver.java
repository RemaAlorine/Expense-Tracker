package com.example.mobilegithub;

import android.app.Activity;
import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import java.util.Calendar;

public class MySmsReceiver extends BroadcastReceiver {
    public static String MY_PREFS="Balance";
    int mode= Activity.MODE_PRIVATE;
    SharedPreferences.Editor editor;
    SharedPreferences prefs;
    String balance;
    Float b;
    DataBaseHelper myDb;
    private static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";



    @Override
    public void onReceive(Context context, Intent intent) {


            editor = context.getSharedPreferences(MY_PREFS, context.MODE_PRIVATE).edit();
            prefs = context.getSharedPreferences(MY_PREFS, context.MODE_PRIVATE);

            balance = prefs.getString("b", "Not Found");
            b=Float.parseFloat(balance);
            myDb = new DataBaseHelper(context);

            if (intent.getAction().equals(SMS_RECEIVED)) {

                Bundle bundle = intent.getExtras();
                if (bundle != null) {

                    // get sms objects
                    Object[] pdus = (Object[]) bundle.get("pdus");
                    if (pdus.length == 0) {

                        return;
                    }
                    // large message might be broken into many
                    SmsMessage[] messages = new SmsMessage[pdus.length];
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < pdus.length; i++) {
                        messages[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                        sb.append(messages[i].getMessageBody());

                    }

                    String sender = messages[0].getOriginatingAddress();
                    String message = sb.toString();
                //   Toast.makeText(context, message, Toast.LENGTH_SHORT).show();

                    //Type:Income.
                    // Category:salary.
                    //Amount:800.
                    //Date:2/10/2023.

                        int s1,s2,s3,s4;
                        int l1,l2,l3,l4;
                        String m1,m2,m3,m4;
                         s1 = message.indexOf("Amount")+7;
                         l1=message.indexOf(".",s1);
                         m1 = message.substring(s1,l1);
                        float salary = Float.parseFloat(m1.replace(" ", ""));

                         s2= message.indexOf("Date")+5;
                         l2=message.indexOf(".",s2);
                         m2=message.substring(s2,l2);
                         String date = m2.replace(" ","");

                        s3= message.indexOf("Type")+5;
                        l3=message.indexOf(".");
                        m3=message.substring(s3,l3);
                        String type= m3.replace(" ","");

                        s4= message.indexOf("Category")+9;
                        l4=message.indexOf(".",s4);
                        m4=message.substring(s4,l4);
                        String category = m4.replace(" ","");







                        if(type.equals("Income")){

                            float newBalance = b + salary;
                            String nb = String.valueOf(newBalance);
                            editor.putString("b", nb);
                            editor.apply();
                            myDb.insertIncome(salary, date, category);



                        }

                        else if(type.equals("Outcome")){
                            float newBalance = b - salary;
                            String nb = String.valueOf(newBalance);
                            editor.putString("b", nb);
                            editor.apply();
                            myDb.insertOutcome(salary, date, category);

                        }
                    }

                }

        }
    }


