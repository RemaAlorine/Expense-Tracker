package com.example.mobilegithub;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.util.Pair;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SecondActivity extends AppCompatActivity {
    private static final int MY_PERMSSIONS_RROUEST_RECRIVE_SMS = 0;
    private static final String SMS ="android.permission.RECEIVE_SMS";
    private static final String SMS_RECEIVED ="android.provider.Telephony.SMS_RECEIVED";
    DataBaseHelper myDb;
   public static TextView current_balance;
    TextView result;
   String amount;

    Button submitButton;

    String radioText;
    SeekBar seekBar;
    TextView amount_selected;
    TextView Amount;
    String period;
    Context context;
    public static String MY_PREFS="Balance";
    int mode= Activity.MODE_PRIVATE;
    String Cbalance;
    static SharedPreferences mysp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        context=this;
        myDb = new DataBaseHelper(this);
        Amount=findViewById(R.id.textView5);
         period="0";
//        registerReceiver(receiver,new IntentFilter("SMS_RECEIVED"));
        current_balance = (TextView)findViewById(R.id.textView_current_amount);
        mysp=getSharedPreferences(MY_PREFS,mode);
        Cbalance=mysp.getString("b","not found");
        current_balance.setText(Cbalance);



        if(ContextCompat.checkSelfPermission(this, SMS)!= PackageManager.PERMISSION_GRANTED)
        {
            if(ActivityCompat.shouldShowRequestPermissionRationale(this,SMS)){

            }

            else {
                ActivityCompat.requestPermissions(this,new String[]{SMS},MY_PERMSSIONS_RROUEST_RECRIVE_SMS);
            }
        }
        seekBar=findViewById(R.id.seekBar3);
        amount_selected=findViewById(R.id.textView13);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                amount_selected.setText("0-"+progress*500);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        submitButton=findViewById(R.id.button);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("tttt", "0" + "");

                result=findViewById(R.id.textView12);
//                dateTextView = findViewById(R.id.dateTextView);
                amount_selected=findViewById(R.id.textView13);
                amount = amount_selected.getText().toString();

                if (result.getText().toString().equals("Type")) {

                    showMessage("Error","Please choose category to display");
                    Log.d("tttt", "2" + "");
                    return;

                }else if (amount.equals("")) {

                    showMessage("Error","Please select amount");
                    return;

                }else if (period.equals("0")) {

                    showMessage("Error","Please select period to display");
                    return;

                }
                    Log.d("tttt", "4" + "");
                    String am = amount.substring(amount.indexOf("-")+1);
                    Float salary = Float.parseFloat(am);
                    Intent next = new Intent(context,ThirdActivity.class);
//                    next.putExtra("type", result.getText().toString());
//                    next.putExtra("category", radioText);
//                    next.putExtra("period", period);
//                    next.putExtra("amount", salary);

                SharedPreferences.Editor editor = mysp.edit();
                editor.putString("type", result.getText().toString());
                editor.putString("category", radioText);
                editor.putString("period", period);
                editor.putFloat("amount", salary);
                editor.apply();
                Log.d("tttt", "01" + "");
                startActivity(next);

//                   myDb.getData(result.getText().toString(), radioText, salary, period);



            }
        });




    }
    public static void updateAmount(){
        current_balance.setText(mysp.getString("b","not found"));
    }

    public void onRadioButtonClicked(View view) {
        result=findViewById(R.id.textView12);
        // Is the view now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which RadioButton was clicked
        switch(view.getId()) {
            case R.id.radioButton4:
            case R.id.radioButton8:
                if (checked) {
                    result.setText("Income");
                    radioText=((RadioButton) view).getText().toString();
                }
               break;
            case R.id.radioButton3:
            case R.id.radioButton2:
            case R.id.radioButton:
               result.setText("Outcome");
               radioText=((RadioButton) view).getText().toString();
                break;
            case R.id.radio0:
            case R.id.radio1:
            case R.id.radio2:
                period=((RadioButton) view).getText().toString();
                break;

        }
    }


    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}