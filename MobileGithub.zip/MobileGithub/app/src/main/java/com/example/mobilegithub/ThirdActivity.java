package com.example.mobilegithub;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.Calendar;

public class ThirdActivity extends AppCompatActivity {
    BarChart barChart;
    PieChart pieChart;
    String t,c,p;
    Float a;
    String[] arr;
    String[] arr2;
    boolean found=false;
    public static String MY_PREFS="Balance";
    int mode= Activity.MODE_PRIVATE;
    SharedPreferences mysp;
    DataBaseHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        mydb=new DataBaseHelper(this);
        mysp=getSharedPreferences(MY_PREFS,mode);
        //values sent from selection
           t= mysp.getString("type", null);
           c= mysp.getString("category", null);
           p= mysp.getString("period", null);
           a= mysp.getFloat("amount", 0f);
        Log.d("tttt", t + "");
        Log.d("tttt", c + "");
        Log.d("tttt", p + "");
        Log.d("tttt", a + "");

        //to get date of this instance to compare with db
        Calendar calendar = Calendar.getInstance();
        String dateText = DateFormat.format("d/M/yyyy", calendar).toString();
        Log.d("tttt", dateText + "");
        barChart=(BarChart) findViewById(R.id.BarChart);
        pieChart=(PieChart) findViewById(R.id.pie_chart);
        ArrayList<BarEntry> info=new ArrayList<>();
        ArrayList<BarEntry> info2=new ArrayList<>();
        ArrayList<BarEntry> info3=new ArrayList<>();
        ArrayList<PieEntry> pie=new ArrayList<>();
        int counter=0;
        //create query or something to get data based on selected period


        if(p.equals("Daily")){

         arr=mydb.getData(t,c);
         Log.d("tttt", "333" + "");
         if(DataBaseHelper.counting<2){
             showMessage("Error","no matching result found");
             return;
         }else {
             Log.d("tttt", "888" + "");
             for (int i = 0; i < DataBaseHelper.counting; i = i + 2) {
                 Log.d("tttt", "55555" + "");
                 Float am = Float.parseFloat(arr[i]);
                 if (am <= a && dateText.equals(arr[i + 1])) {
                     found=true;

                     counter += 2;
                     info.add(new BarEntry(counter, am));

                 }


             }
             if(!found){
                 showMessage("Error","no matching result found");
                 return;
             }
             BarDataSet dataSet = new BarDataSet(info, p + c + " Report");
             dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
             dataSet.setValueTextColor(Color.BLACK);
             dataSet.setValueTextSize(20f);

             BarData barData = new BarData(dataSet);
             barChart.setFitBars(true);
             barChart.setData(barData);
             barChart.getDescription().setText(c + "Report");
             barChart.animateY(2000);
         }
        }else if(p.equals("Monthly")){
           arr= mydb.getData(t,c);
            Log.d("tttt", "888" + "");
            if(DataBaseHelper.counting<2){
                showMessage("Error","no matching result found");
                return;
            }else {
                for (int i = 0; i < DataBaseHelper.counting; i = i + 2) {
                    Log.d("tttt", ";;;;" + "");
                    Float am = Float.parseFloat(arr[i]);
                    String month = dateText.substring(dateText.indexOf("/") + 1);
                    String month2 = arr[i + 1].substring(arr[i + 1].indexOf("/") + 1);
                    Integer day = Integer.parseInt(arr[i + 1].substring(0, arr[i + 1].indexOf("/")));
                    Log.d("tttt", month + "");
                    Log.d("tttt", month2 + "");
                    if (am <= a && month.equals(month2)) {
                        found=true;
                        counter += 2;
                        info2.add(new BarEntry(day, am));
                        Log.d("tttt", "///" + "");
                    }
                }


                for (int j = 0; j < info2.size(); j++) {
                    Log.d("tttt", info2.get(j).toString());
                }

                if(!found){
                    showMessage("Error","no matching result found");
                    return;
                }

                BarDataSet dataSet = new BarDataSet(info2, p + " " + c + " Report");
                dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
                dataSet.setValueTextColor(Color.BLACK);
                dataSet.setValueTextSize(20f);

                BarData barData = new BarData(dataSet);
                barChart.setFitBars(true);
                barChart.setData(barData);
                barChart.getDescription().setText(c + "Report");
                barChart.animateY(2000);

            }
        }else{  //Yarly
           arr= mydb.getData(t,c);
            if(DataBaseHelper.counting<2){
                showMessage("Error","no matching result found");
                return;
            }else{
            for(int i=0;i<DataBaseHelper.counting;i=i+2){

                Float am=Float.parseFloat(arr[i]);
                 //2/10/2023
                String month=dateText.substring(dateText.indexOf("/")+1);
                String year=month.substring(month.indexOf("/")+1);

                String month2=arr[i+1].substring(arr[i+1].indexOf("/")+1);
               String month3=month2.substring(0,month2.indexOf("/"));
                String year2=month2.substring(month2.indexOf("/")+1);
               Integer y=Integer.parseInt(month3);
                Log.d("tttt",month+"  "+month2+"  "+year+"  "+year2);
                Log.d("tttt",y.toString());
                if(am<=a && year.equals(year2)){
                    found=true;

                    counter+=2;
                    info3.add(new BarEntry(y,am));

                }


            }
                if(!found){
                    showMessage("Error","no matching result found");
                    return;
                }
            BarDataSet dataSet=new BarDataSet(info3,p+" "+c+" Report");
            dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
            dataSet.setValueTextColor(Color.BLACK);
            dataSet.setValueTextSize(20f);

            BarData barData= new BarData(dataSet);
            barChart.setFitBars(true);
            barChart.setData(barData);
            barChart.getDescription().setText(c+"Report");
            barChart.animateY(2000);
        }}


            arr2 = mydb.getAllData();
        Log.d("tttt", "h1" + "");
            if (DataBaseHelper.counting<2) {
                showMessage("Error", "no matching result found");
                return;
            }else{
                Log.d("tttt", "8h4" + "");
            Float cost1 = 0f, cost2 = 0f;
//        ,cost3=0f,cost4=0f,cost5=0f;
            //int c1=0,c2=0,c3=0,c4=0,c5=0;
                Log.d("tttt", DataBaseHelper.counting + "");
            for (int i = 0; i < DataBaseHelper.counting; i = i + 2) {

                if (arr2[i].equals("Income")) {
                    Log.d("tttt", "8hghghjg" + "");
                    Float am = Float.parseFloat(arr2[i + 1]);
                    cost1 += am;
                } else {
                    Float am = Float.parseFloat(arr2[i + 1]);
                    cost2 += am;
                }

            }
//            }else if(arr2[i].equals("Outgoing Transfers")){
//                c3++;
//                Float am = Float.parseFloat(arr2[i+1]);
//                cost3+=am;
//            }else if(arr2[i].equals("purchases")){
//                c4++;
//                Float am = Float.parseFloat(arr2[i+1]);
//                cost4+=am;
//            }if(arr2[i].equals("monthly Redemption")){
//                c5++;
//                Float am = Float.parseFloat(arr2[i+1]);
//                cost5+=am;
//            }


            pie.add(new PieEntry(cost1, "Income"));
            pie.add(new PieEntry(cost2, "Outcome"));
//                pie.add(new PieEntry(c3,"Outgoing Transfers = "+cost3));
//                pie.add(new PieEntry(c4,"purchases = "+cost4));
//                pie.add(new PieEntry(c5,"monthly Redemption = "+cost5));

            PieDataSet dataSet2 = new PieDataSet(pie, "Incomes and Outcomes");
            dataSet2.setColors(ColorTemplate.COLORFUL_COLORS);
            dataSet2.setValueTextColor(Color.BLACK);
            dataSet2.setValueTextSize(22f);

            PieData pieData = new PieData(dataSet2);

            pieChart.setData(pieData);
            pieChart.getDescription().setText("Report For All Incomes And Outcomes");
            pieChart.animate();

        }}






    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}