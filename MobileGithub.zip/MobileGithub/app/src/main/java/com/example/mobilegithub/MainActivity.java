package com.example.mobilegithub;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DataBaseHelper myDb;
    EditText editBalance;
    Button submitbutton;

    private static final int MY_PERMSSIONS_RROUEST_RECRIVE_SMS = 0;
    private static final String SMS ="android.permission.RECEIVE_SMS";
    private static final String SMS_RECEIVED ="android.provider.Telephony.SMS_RECEIVED";
    String iniBalance;
    public static String MY_PREFS = "Balance";
    int mode = Activity.MODE_PRIVATE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new DataBaseHelper(this);
        // myDb.deleteData();
        editBalance = findViewById(R.id.editText_balance);

        submitbutton = findViewById(R.id.button_submit);
        submitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData();
//
            }
        });


        if(ContextCompat.checkSelfPermission(this, SMS)!= PackageManager.PERMISSION_GRANTED)
        {
            if(ActivityCompat.shouldShowRequestPermissionRationale(this,SMS)){

            }

            else {
                ActivityCompat.requestPermissions(this,new String[]{SMS},MY_PERMSSIONS_RROUEST_RECRIVE_SMS);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

    }
    //broadcastReceiver
    @Override
    protected void onDestroy() {
        super.onDestroy();

    }


    @SuppressLint("SuspiciousIndentation")
    public void saveData() {

        SharedPreferences mysp = getSharedPreferences(MY_PREFS, mode);
        SharedPreferences.Editor editor = mysp.edit();
        iniBalance= editBalance.getText().toString();
       if(checkField(iniBalance)) {
           editor.putString("b", iniBalance);
           if (editor.commit() == true) {
               Toast.makeText(MainActivity.this, "Balance Saved", Toast.LENGTH_LONG).show();
//                    editBalance.setText("");
               Intent intent = new Intent(getApplicationContext(), SecondActivity.class);
               startActivity(intent);
           } else
              showMessage("Error","Something went wrong,Try again");
       }
       else
       showMessage("Error","Please check entered information");
    }

    private boolean checkField(String balance) {
        if (balance.length() == 0) {
            editBalance.requestFocus();
            editBalance.setError("This field is required");
            return false;
        } else if (!balance.matches("-?[0-9]*(\\.[0-9]*)?")) {
            editBalance.requestFocus();
            editBalance.setError("only numbers are allowed");
            return false;
        } else if (Float.parseFloat(balance) <= 0) {
            editBalance.requestFocus();
            editBalance.setError("please inter positive balance");
            return false;
        } else
            return true;
    }

    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}