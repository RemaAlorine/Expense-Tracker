package com.example.mobilegithub;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Expenses.db";

    public static final String TABLE_NAME2 = "expenses_table";
SecondActivity secondActivity= new SecondActivity();
    public static final String T2_col_1 = "ID";
    public static final String T2_col_2 = "TYPE";
    public static final String T2_col_3 = "AMOUNT";
    public static final String T2_col_4 = "CATEGORY";
    public static final String T2_col_5 = "PERIOD";
    public static int counting=0;



    public DataBaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME2 + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, TYPE TEXT,AMOUNT REAL,CATEGORY TEXT,PERIOD TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME2);
        onCreate(db);
    }

    public void insertIncome(Float amount,String date,String type){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(T2_col_2,"Income");
        contentValues.put(T2_col_3,amount);
        contentValues.put(T2_col_4,type);
        contentValues.put(T2_col_5,date);
        long result = db.insert(TABLE_NAME2, null, contentValues);
   secondActivity.updateAmount();

    }

    public void insertOutcome(Float amount,String date,String type){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(T2_col_2,"Outcome");
        contentValues.put(T2_col_3,amount);
        contentValues.put(T2_col_4,type);
        contentValues.put(T2_col_5,date);
        long result = db.insert(TABLE_NAME2, null, contentValues);
        secondActivity.updateAmount();

    }

//    public boolean insertIniBalance(String balance) {
//        //needs input validation!!!!!!!!!
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//        contentValues.put(T1_col_2, balance);
//        long result = db.insert(TABLE_NAME1, null, contentValues);
//
//        if (result == -1)
//            return false;
//        else
//            return true;
//    }

    public String[] getData(String type,String category){
        counting=0;
        Log.d("tttt", "04!" + "");
        Log.d("tttt",counting + "new");
        int index=0;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns={"TYPE","AMOUNT","CATEGORY","PERIOD"};
        String[] arr=new String[50];
        String[] conditions={type,category};
        Cursor res =db.query(TABLE_NAME2,columns,"TYPE = ? And CATEGORY = ? ",conditions,null,null,null);
        int amountCol=res.getColumnIndex("AMOUNT");
        int periodCol=res.getColumnIndex("PERIOD");
        while(res.moveToNext()){
            Log.d("tttt", "++++++++++++" + "");
            arr[index++]=res.getString(amountCol);
           arr[index++]=res.getString(periodCol);
           counting+=2;

        }
        return arr;
    }
    public void deleteData(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME2,null, null);
    }

    public String[] getAllData(){
        counting=0;
        int index=0;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns={"TYPE","AMOUNT","CATEGORY","PERIOD"};
        String[] arr=new String[50];

        Cursor res =db.query(TABLE_NAME2,columns,null,null,null,null,null);
        int amountCol=res.getColumnIndex("AMOUNT");
        int periodCol=res.getColumnIndex("TYPE");
        while(res.moveToNext()){
            Log.d("tttt", "$$$$$+" + "");

            arr[index++]=res.getString(periodCol);
            arr[index++]=res.getString(amountCol);
            counting+=2;

        }
        return arr;
    }
//
//    public boolean updateData(String id,String name , String surname , String marks) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//        contentValues.put(col_1,id);
//        contentValues.put(col_2,name);
//        contentValues.put(col_3,surname);
//        contentValues.put(col_4,marks);
//        db.update(TABLE_NAME,contentValues,"ID = ? ", new String[] { id });
//        return true;
//    }


}
